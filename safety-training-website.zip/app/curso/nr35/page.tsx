"use client"

import { useState } from "react"
import { CourseHero } from "@/components/course/course-hero"
import { CourseHeader } from "@/components/course/course-header"
import { CourseNavigation } from "@/components/course/course-navigation"
import { CourseContent } from "@/components/course/course-content"
import { CourseProgress } from "@/components/course/course-progress"
import { CourseCertificate } from "@/components/course/course-certificate"
import { CourseMaterials } from "@/components/course/course-materials"

const courseInfo = {
  title: "NR-35 - Trabalho em Altura",
  description:
    "Curso completo sobre segurança em trabalhos em altura conforme NR-35. Aprenda procedimentos, EPIs e análise de riscos.",
  image: "/images/courses/nr35-cover.png",
  duration: "8 horas",
  students: "2.500+",
  rating: 4.9,
  price: "R$ 89,90",
  originalPrice: "R$ 149,90",
  badge: "Mais Vendido",
  category: "altura",
  level: "Básico",
  modules: 5,
}

const courseModules = [
  {
    id: 1,
    title: "Introdução à NR-35",
    duration: "15 min",
    completed: false,
    content: {
      type: "video",
      title: "Bem-vindo ao Curso NR-35 - Trabalho em Altura",
      description:
        "Neste módulo você aprenderá os conceitos básicos sobre trabalho em altura e a importância da NR-35.",
      videoUrl: "/placeholder.svg?height=400&width=600",
      materials: [
        "Manual da NR-35 atualizado",
        "Checklist de segurança",
        "Glossário de termos técnicos",
        "Apresentação NR-35 Completa (PPTX)",
      ],
    },
  },
  {
    id: 2,
    title: "Conceitos e Definições",
    duration: "20 min",
    completed: false,
    content: {
      type: "text",
      title: "Definições Importantes da NR-35",
      description: "Conceitos fundamentais que todo profissional deve conhecer.",
      text: `
        <h3>Trabalho em Altura</h3>
        <p>Considera-se trabalho em altura toda atividade executada acima de 2,00 m (dois metros) do nível inferior, onde haja risco de queda.</p>
        
        <h3>Equipamentos de Proteção Individual (EPI)</h3>
        <p>Dispositivos ou produtos, de uso individual utilizado pelo trabalhador, destinado à proteção de riscos suscetíveis de ameaçar a segurança e a saúde no trabalho.</p>
        
        <h3>Sistema de Proteção Coletiva (SPC)</h3>
        <p>Medidas de proteção aplicáveis a um grupo de trabalhadores, como guarda-corpos, redes de segurança, etc.</p>
        
        <h3>Análise de Risco (AR)</h3>
        <p>Avaliação dos riscos de queda a que estão expostos os trabalhadores, bem como das medidas de prevenção e proteção a serem adotadas.</p>
      `,
      materials: ["Cartilha de definições NR-35", "Exemplos práticos ilustrados", "Apresentação NR-35 Completa (PPTX)"],
    },
  },
  {
    id: 3,
    title: "Equipamentos de Segurança",
    duration: "25 min",
    completed: false,
    content: {
      type: "interactive",
      title: "Conhecendo os EPIs para Trabalho em Altura",
      description: "Aprenda sobre os principais equipamentos de proteção individual.",
      interactive: {
        type: "equipment-gallery",
        items: [
          {
            name: "Cinturão de Segurança",
            image: "/placeholder.svg?height=200&width=200",
            description: "Equipamento de proteção individual utilizado para sustentação do trabalhador.",
          },
          {
            name: "Capacete",
            image: "/placeholder.svg?height=200&width=200",
            description: "Proteção da cabeça contra impactos e quedas de objetos.",
          },
          {
            name: "Trava-quedas",
            image: "/placeholder.svg?height=200&width=200",
            description: "Dispositivo que trava automaticamente em caso de queda.",
          },
        ],
      },
      materials: [
        "Catálogo de EPIs aprovados",
        "Manual de inspeção de equipamentos",
        "Apresentação NR-35 Completa (PPTX)",
      ],
    },
  },
  {
    id: 4,
    title: "Procedimentos de Segurança",
    duration: "30 min",
    completed: false,
    content: {
      type: "checklist",
      title: "Procedimentos Obrigatórios",
      description: "Passo a passo dos procedimentos de segurança.",
      checklist: [
        "Realizar Análise de Risco (AR)",
        "Verificar condições meteorológicas",
        "Inspecionar todos os EPIs",
        "Verificar pontos de ancoragem",
        "Estabelecer sistema de comunicação",
        "Definir plano de resgate",
        "Treinar a equipe de trabalho",
        "Supervisionar continuamente",
      ],
      materials: ["Formulário de AR", "Checklist de inspeção", "Apresentação NR-35 Completa (PPTX)"],
    },
  },
  {
    id: 5,
    title: "Avaliação Final",
    duration: "20 min",
    completed: false,
    content: {
      type: "quiz",
      title: "Teste seus Conhecimentos",
      description: "Responda às questões para concluir o curso.",
      questions: [
        {
          question: "A partir de quantos metros de altura é considerado trabalho em altura?",
          options: ["1,5 metros", "2,0 metros", "2,5 metros", "3,0 metros"],
          correct: 1,
        },
        {
          question: "Qual é o primeiro procedimento antes de iniciar trabalho em altura?",
          options: ["Colocar o EPI", "Fazer a Análise de Risco", "Verificar o clima", "Chamar o supervisor"],
          correct: 1,
        },
        {
          question: "O que significa EPI?",
          options: [
            "Equipamento de Proteção Individual",
            "Equipamento de Prevenção Industrial",
            "Equipamento de Proteção Integral",
            "Equipamento de Prevenção Individual",
          ],
          correct: 0,
        },
      ],
      materials: ["Gabarito da avaliação", "Apresentação NR-35 Completa (PPTX)"],
    },
  },
]

export default function NR35CoursePage() {
  const [showCourse, setShowCourse] = useState(false)
  const [currentModule, setCurrentModule] = useState(1)
  const [modules, setModules] = useState(courseModules)
  const [courseCompleted, setCourseCompleted] = useState(false)
  const [userProgress, setUserProgress] = useState({
    completedModules: 0,
    totalModules: courseModules.length,
    currentModule: 1,
    timeSpent: 0,
  })

  const completeModule = (moduleId: number) => {
    setModules((prev) => prev.map((module) => (module.id === moduleId ? { ...module, completed: true } : module)))

    setUserProgress((prev) => ({
      ...prev,
      completedModules: prev.completedModules + 1,
    }))

    // Check if course is completed
    const updatedModules = modules.map((module) => (module.id === moduleId ? { ...module, completed: true } : module))

    if (updatedModules.every((module) => module.completed)) {
      setCourseCompleted(true)
    }
  }

  const nextModule = () => {
    if (currentModule < modules.length) {
      setCurrentModule(currentModule + 1)
      setUserProgress((prev) => ({ ...prev, currentModule: currentModule + 1 }))
    }
  }

  const previousModule = () => {
    if (currentModule > 1) {
      setCurrentModule(currentModule - 1)
      setUserProgress((prev) => ({ ...prev, currentModule: currentModule - 1 }))
    }
  }

  if (courseCompleted) {
    return <CourseCertificate courseName="NR-35 - Trabalho em Altura" />
  }

  if (!showCourse) {
    return (
      <div>
        <CourseHero course={courseInfo} />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <button
              onClick={() => setShowCourse(true)}
              className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 rounded-lg text-lg font-medium transition-colors"
            >
              Iniciar Curso Agora
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <CourseHeader courseName="NR-35 - Trabalho em Altura" progress={userProgress} />

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <CourseNavigation modules={modules} currentModule={currentModule} onModuleSelect={setCurrentModule} />
            <div className="mt-6">
              <CourseProgress progress={userProgress} />
            </div>
            <div className="mt-6">
              <CourseMaterials />
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <CourseContent
              module={modules.find((m) => m.id === currentModule)!}
              onComplete={() => completeModule(currentModule)}
              onNext={nextModule}
              onPrevious={previousModule}
              canGoNext={currentModule < modules.length}
              canGoPrevious={currentModule > 1}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
