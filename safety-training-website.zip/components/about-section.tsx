import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award, Users, Clock, Shield } from "lucide-react"

export function AboutSection() {
  const stats = [
    { icon: Users, value: "15.000+", label: "Alunos Certificados" },
    { icon: Award, value: "50+", label: "Cursos Disponíveis" },
    { icon: Clock, value: "10+", label: "Anos de Experiência" },
    { icon: Shield, value: "100%", label: "Certificados Válidos" },
  ]

  return (
    <section id="sobre" className="py-20 bg-blue-50">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <Badge className="bg-green-500 hover:bg-green-600 text-white px-4 py-2">
                Sobre a Segurança no Trampo
              </Badge>
              <h2 className="text-4xl font-bold text-gray-900">Referência em Treinamentos de Segurança do Trabalho</h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                Há mais de 10 anos no mercado, somos especializados em capacitação profissional e consultoria em
                Segurança e Saúde no Trabalho. Nossa missão é proteger vidas através do conhecimento e da prevenção.
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-gray-900">Por que escolher a Segurança no Trampo?</h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700">Certificados reconhecidos pelo Ministério do Trabalho</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700">Instrutores qualificados e experientes</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700">Metodologia prática e atualizada</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700">Suporte técnico especializado 24/7</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-gray-700">Plataforma online moderna e intuitiva</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="space-y-8">
            <div className="relative">
              <img
                src="/placeholder.svg?height=400&width=500"
                alt="Treinamento de segurança do trabalho"
                className="w-full h-auto rounded-2xl shadow-lg"
              />
            </div>

            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <Card key={index} className="text-center p-6 border-0 shadow-md">
                  <CardContent className="p-0">
                    <div className="flex justify-center mb-3">
                      <stat.icon className="h-8 w-8 text-green-500" />
                    </div>
                    <div className="text-3xl font-bold text-blue-900 mb-1">{stat.value}</div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
