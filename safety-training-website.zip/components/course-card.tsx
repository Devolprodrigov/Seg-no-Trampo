"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, Users, Star, Play, Award, Shield } from "lucide-react"
import Link from "next/link"
import { CoursePreviewModal } from "@/components/course-preview-modal"

interface CourseCardProps {
  course: {
    id: string
    title: string
    description: string
    image: string
    duration: string
    students: string
    rating: number
    price: string
    originalPrice: string
    badge: string
    category: string
    level: string
    modules: number
  }
}

export function CourseCard({ course }: CourseCardProps) {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "altura":
        return "🏗️"
      case "espacos-confinados":
        return "🏭"
      case "eletricidade":
        return "⚡"
      case "cipa":
        return "👥"
      case "primeiros-socorros":
        return "🚑"
      case "soldagem":
        return "🔥"
      case "equipamentos":
        return "🚛"
      case "transporte":
        return "🚗"
      case "investigacao":
        return "🔍"
      case "metodologia":
        return "❓"
      case "gestao-riscos":
        return "⚠️"
      default:
        return "🛡️"
    }
  }

  const getLevelColor = (level: string) => {
    switch (level) {
      case "Básico":
        return "bg-green-100 text-green-700"
      case "Intermediário":
        return "bg-yellow-100 text-yellow-700"
      case "Avançado":
        return "bg-red-100 text-red-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 border-0 shadow-md group">
      <div className="relative overflow-hidden">
        <div className="w-full h-48 bg-gradient-to-br from-yellow-400 to-yellow-500 flex items-center justify-center">
          <img
            src={course.image || "/placeholder.svg"}
            alt={course.title}
            className="w-32 h-32 object-contain transition-transform duration-300 group-hover:scale-110"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />

        {/* Category Icon */}
        <div className="absolute top-3 left-3">
          <div className="bg-white/90 backdrop-blur-sm rounded-full p-2 text-lg">
            {getCategoryIcon(course.category)}
          </div>
        </div>

        {/* Badge */}
        <Badge className="absolute top-3 right-3 bg-green-500 hover:bg-green-600 text-white">{course.badge}</Badge>

        {/* Level Badge */}
        <Badge className={`absolute bottom-3 left-3 ${getLevelColor(course.level)}`}>{course.level}</Badge>

        {/* Play Button Overlay */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <CoursePreviewModal course={course}>
            <Button size="sm" className="bg-white text-black hover:bg-gray-100">
              <Play className="h-4 w-4 mr-2" />
              Preview
            </Button>
          </CoursePreviewModal>
        </div>
      </div>

      <CardHeader className="pb-3">
        <div className="flex items-start justify-between mb-2">
          <CardTitle className="text-lg text-gray-900 line-clamp-2 flex-1">{course.title}</CardTitle>
          <div className="flex items-center gap-1 ml-2">
            <Award className="h-4 w-4 text-green-500" />
            <span className="text-xs text-green-600 font-medium">MTE</span>
          </div>
        </div>
        <CardDescription className="text-gray-600 line-clamp-2">{course.description}</CardDescription>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="grid grid-cols-2 gap-4 text-sm text-gray-500 mb-4">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            {course.duration}
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            {course.students}
          </div>
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
            {course.rating}
          </div>
          <div className="flex items-center gap-1">
            <Shield className="h-4 w-4" />
            {course.modules} módulos
          </div>
        </div>

        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-2xl font-bold text-green-600">{course.price}</span>
            <span className="text-sm text-gray-500 line-through ml-2">{course.originalPrice}</span>
          </div>
          <div className="text-right">
            <div className="text-xs text-gray-500">Economia</div>
            <div className="text-sm font-semibold text-green-600">
              {Math.round(
                ((Number.parseFloat(course.originalPrice.replace("R$ ", "").replace(",", ".")) -
                  Number.parseFloat(course.price.replace("R$ ", "").replace(",", "."))) /
                  Number.parseFloat(course.originalPrice.replace("R$ ", "").replace(",", "."))) *
                  100,
              )}
              %
            </div>
          </div>
        </div>

        <Link href={`/curso/${course.id}`}>
          <Button className="w-full bg-green-500 hover:bg-green-600 transition-colors">Matricular Agora</Button>
        </Link>
      </CardContent>
    </Card>
  )
}
