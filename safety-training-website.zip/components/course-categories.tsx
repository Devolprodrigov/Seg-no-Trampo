"use client"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface CourseCategoriesProps {
  onCategoryChange: (category: string) => void
  activeCategory: string
}

export function CourseCategories({ onCategoryChange, activeCategory }: CourseCategoriesProps) {
  const categories = [
    { id: "all", name: "Todos os Cursos", icon: "🛡️", count: 11 },
    { id: "altura", name: "Trabalho em Altura", icon: "🏗️", count: 1 },
    { id: "espacos-confinados", name: "Espaços Confinados", icon: "🏭", count: 1 },
    { id: "eletricidade", name: "Segurança Elétrica", icon: "⚡", count: 1 },
    { id: "cipa", name: "CIPA", icon: "👥", count: 1 },
    { id: "primeiros-socorros", name: "Primeiros Socorros", icon: "🚑", count: 1 },
    { id: "soldagem", name: "Soldagem", icon: "🔥", count: 1 },
    { id: "equipamentos", name: "Equipamentos", icon: "🚛", count: 1 },
    { id: "transporte", name: "Transporte", icon: "🚗", count: 1 },
    { id: "investigacao", name: "Investigação", icon: "🔍", count: 1 },
    { id: "metodologia", name: "Metodologias", icon: "❓", count: 1 },
    { id: "gestao-riscos", name: "Gestão de Riscos", icon: "⚠️", count: 1 },
  ]

  return (
    <div className="mb-8">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Categorias</h3>
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={activeCategory === category.id ? "default" : "outline"}
            size="sm"
            onClick={() => onCategoryChange(category.id)}
            className={`${
              activeCategory === category.id
                ? "bg-green-500 hover:bg-green-600 text-white"
                : "border-gray-300 text-gray-700 hover:bg-gray-50"
            }`}
          >
            <span className="mr-2">{category.icon}</span>
            {category.name}
            <Badge variant="secondary" className="ml-2 bg-gray-100 text-gray-600">
              {category.count}
            </Badge>
          </Button>
        ))}
      </div>
    </div>
  )
}
