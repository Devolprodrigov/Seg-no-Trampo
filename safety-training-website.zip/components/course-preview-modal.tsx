"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, ChevronLeft, ChevronRight, Download, Clock, Users, Star } from "lucide-react"

interface CoursePreviewModalProps {
  course: {
    id: string
    title: string
    description: string
    duration: string
    students: string
    rating: number
    price: string
    originalPrice: string
    modules: number
  }
  children: React.ReactNode
}

export function CoursePreviewModal({ course, children }: CoursePreviewModalProps) {
  const [currentSlide, setCurrentSlide] = useState(0)

  // Slides de preview para cada curso
  const getPreviewSlides = (courseId: string) => {
    switch (courseId) {
      case "nr35":
        return [
          {
            title: "NR-35 - TRABALHO EM ALTURA",
            subtitle: "Segurança no Trampo - Treinamentos & Assessoria",
            content: "Curso completo sobre segurança em trabalhos em altura conforme Norma Regulamentadora 35",
            image: "/placeholder.svg?height=400&width=600&text=NR-35+Capa",
            type: "cover",
          },
          {
            title: "O QUE É TRABALHO EM ALTURA?",
            content:
              "Considera-se trabalho em altura toda atividade executada acima de 2,00 m (dois metros) do nível inferior, onde haja risco de queda.",
            bulletPoints: [
              "Altura mínima: 2,00 metros",
              "Presença de risco de queda",
              "Atividades em telhados, andaimes, escadas",
              "Trabalhos em torres e estruturas",
            ],
            image: "/placeholder.svg?height=300&width=400&text=Trabalho+em+Altura",
            type: "content",
          },
          {
            title: "EQUIPAMENTOS DE PROTEÇÃO",
            content: "EPIs essenciais para trabalho em altura:",
            bulletPoints: [
              "Cinturão de segurança tipo paraquedista",
              "Capacete com jugular",
              "Trava-quedas automático",
              "Conectores e mosquetões",
              "Cordas e cabos de segurança",
            ],
            image: "/placeholder.svg?height=300&width=400&text=EPIs+Altura",
            type: "content",
          },
        ]

      case "nr33":
        return [
          {
            title: "NR-33 - ESPAÇOS CONFINADOS",
            subtitle: "Segurança no Trampo - Treinamentos & Assessoria",
            content: "Treinamento essencial para trabalhos em espaços confinados",
            image: "/placeholder.svg?height=400&width=600&text=NR-33+Capa",
            type: "cover",
          },
          {
            title: "DEFINIÇÃO DE ESPAÇO CONFINADO",
            content: "Área fechada com meios limitados de entrada e saída:",
            bulletPoints: ["Tanques, vasos e silos", "Tubulações e dutos", "Poços e fossas", "Túneis e galerias"],
            image: "/placeholder.svg?height=300&width=400&text=Espaço+Confinado",
            type: "content",
          },
        ]

      case "empilhadeira":
        return [
          {
            title: "OPERADOR DE EMPILHADEIRA",
            subtitle: "Segurança no Trampo - Treinamentos & Assessoria",
            content: "Capacitação completa para operação segura de empilhadeiras",
            image: "/placeholder.svg?height=400&width=600&text=Empilhadeira+Capa",
            type: "cover",
          },
          {
            title: "TIPOS DE EMPILHADEIRAS",
            content: "Principais modelos utilizados na indústria:",
            bulletPoints: [
              "Empilhadeira contrabalançada",
              "Empilhadeira retrátil",
              "Empilhadeira lateral",
              "Paleteira elétrica",
            ],
            image: "/placeholder.svg?height=300&width=400&text=Tipos+Empilhadeira",
            type: "content",
          },
        ]

      case "direcao-defensiva":
        return [
          {
            title: "DIREÇÃO DEFENSIVA",
            subtitle: "Segurança no Trampo - Treinamentos & Assessoria",
            content: "Técnicas de direção defensiva para prevenção de acidentes",
            image: "/placeholder.svg?height=400&width=600&text=Direção+Defensiva+Capa",
            type: "cover",
          },
          {
            title: "PRINCÍPIOS DA DIREÇÃO DEFENSIVA",
            content: "Fundamentos para uma condução segura:",
            bulletPoints: [
              "Conhecimento das regras de trânsito",
              "Atenção constante ao ambiente",
              "Previsão de situações de risco",
              "Decisão rápida e segura",
            ],
            image: "/placeholder.svg?height=300&width=400&text=Princípios+Direção",
            type: "content",
          },
        ]

      default:
        return [
          {
            title: course.title.toUpperCase(),
            subtitle: "Segurança no Trampo - Treinamentos & Assessoria",
            content: course.description,
            image: "/placeholder.svg?height=400&width=600&text=Preview+Curso",
            type: "cover",
          },
        ]
    }
  }

  const slides = getPreviewSlides(course.id)

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden p-0">
        <div className="relative">
          {/* Header */}
          <DialogHeader className="p-6 pb-4 border-b">
            <div className="flex items-center justify-between">
              <div>
                <DialogTitle className="text-xl font-bold">{course.title}</DialogTitle>
                <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {course.duration}
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    {course.students}
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    {course.rating}
                  </div>
                </div>
              </div>
              <Badge className="bg-green-500 hover:bg-green-600">Preview Gratuito</Badge>
            </div>
          </DialogHeader>

          {/* Slide Content */}
          <div className="relative bg-gradient-to-br from-blue-900 to-blue-800 text-white min-h-[500px]">
            <div className="absolute inset-0 bg-black/20"></div>

            <div className="relative z-10 p-8">
              {slides[currentSlide].type === "cover" ? (
                // Slide de Capa
                <div className="text-center space-y-6">
                  <div className="mb-8">
                    <h1 className="text-4xl font-bold mb-4">{slides[currentSlide].title}</h1>
                    <p className="text-xl text-blue-200 mb-2">{slides[currentSlide].subtitle}</p>
                    <div className="w-24 h-1 bg-yellow-400 mx-auto"></div>
                  </div>

                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 max-w-2xl mx-auto">
                    <p className="text-lg leading-relaxed">{slides[currentSlide].content}</p>
                  </div>

                  <div className="grid grid-cols-3 gap-4 max-w-md mx-auto mt-8">
                    <div className="text-center p-3 bg-white/10 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-400">{course.modules}</div>
                      <div className="text-sm">Módulos</div>
                    </div>
                    <div className="text-center p-3 bg-white/10 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-400">{course.duration}</div>
                      <div className="text-sm">Duração</div>
                    </div>
                    <div className="text-center p-3 bg-white/10 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-400">MTE</div>
                      <div className="text-sm">Certificado</div>
                    </div>
                  </div>
                </div>
              ) : (
                // Slide de Conteúdo
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div className="space-y-6">
                    <h2 className="text-3xl font-bold text-yellow-400">{slides[currentSlide].title}</h2>
                    <p className="text-lg text-blue-100">{slides[currentSlide].content}</p>

                    {slides[currentSlide].bulletPoints && (
                      <ul className="space-y-3">
                        {slides[currentSlide].bulletPoints.map((point, index) => (
                          <li key={index} className="flex items-start gap-3">
                            <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2 flex-shrink-0"></div>
                            <span className="text-blue-100">{point}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>

                  <div className="text-center">
                    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                      <img
                        src={slides[currentSlide].image || "/placeholder.svg"}
                        alt="Conteúdo do curso"
                        className="w-full h-64 object-cover rounded-lg"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Navigation */}
            {slides.length > 1 && (
              <>
                <button
                  onClick={prevSlide}
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 rounded-full p-2 transition-colors"
                  disabled={currentSlide === 0}
                >
                  <ChevronLeft className="h-6 w-6" />
                </button>

                <button
                  onClick={nextSlide}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 rounded-full p-2 transition-colors"
                  disabled={currentSlide === slides.length - 1}
                >
                  <ChevronRight className="h-6 w-6" />
                </button>
              </>
            )}

            {/* Slide Indicators */}
            {slides.length > 1 && (
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                {slides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      index === currentSlide ? "bg-yellow-400" : "bg-white/40"
                    }`}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-6 border-t bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div>
                  <span className="text-2xl font-bold text-green-600">{course.price}</span>
                  <span className="text-sm text-gray-500 line-through ml-2">{course.originalPrice}</span>
                </div>
                <Badge variant="outline" className="text-green-600 border-green-600">
                  Slide {currentSlide + 1} de {slides.length}
                </Badge>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Baixar Material
                </Button>
                <Button className="bg-green-500 hover:bg-green-600">
                  <Play className="h-4 w-4 mr-2" />
                  Matricular Agora
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
