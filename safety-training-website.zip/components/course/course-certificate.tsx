"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, Share2, Trophy, Calendar, Clock } from "lucide-react"

interface CourseCertificateProps {
  courseName: string
}

export function CourseCertificate({ courseName }: CourseCertificateProps) {
  const currentDate = new Date().toLocaleDateString("pt-BR")
  const studentName = "João Silva" // Em um app real, viria do contexto do usuário

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Success Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-4">
              <Trophy className="h-10 w-10 text-green-600" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Parabéns!</h1>
            <p className="text-xl text-gray-600">Você concluiu o curso com sucesso!</p>
          </div>

          {/* Certificate */}
          <Card className="mb-8 shadow-lg">
            <CardContent className="p-12">
              <div className="text-center border-4 border-green-500 p-8 bg-gradient-to-br from-white to-green-50">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-green-700 mb-2">CERTIFICADO DE CONCLUSÃO</h2>
                  <div className="w-24 h-1 bg-green-500 mx-auto"></div>
                </div>

                <div className="mb-8">
                  <p className="text-lg text-gray-700 mb-4">Certificamos que</p>
                  <h3 className="text-3xl font-bold text-gray-900 mb-4">{studentName}</h3>
                  <p className="text-lg text-gray-700 mb-2">concluiu com aproveitamento o curso</p>
                  <h4 className="text-2xl font-semibold text-green-700 mb-6">{courseName}</h4>
                </div>

                <div className="grid md:grid-cols-3 gap-6 mb-8">
                  <div className="text-center">
                    <Calendar className="h-6 w-6 text-green-600 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">Data de Conclusão</p>
                    <p className="font-semibold">{currentDate}</p>
                  </div>
                  <div className="text-center">
                    <Clock className="h-6 w-6 text-green-600 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">Carga Horária</p>
                    <p className="font-semibold">8 horas</p>
                  </div>
                  <div className="text-center">
                    <Trophy className="h-6 w-6 text-green-600 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">Aproveitamento</p>
                    <p className="font-semibold">95%</p>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <div className="grid md:grid-cols-2 gap-8">
                    <div className="text-center">
                      <div className="w-32 h-1 bg-gray-400 mx-auto mb-2"></div>
                      <p className="text-sm font-semibold">Segurança no Trampo</p>
                      <p className="text-xs text-gray-600">Instituição de Ensino</p>
                    </div>
                    <div className="text-center">
                      <div className="w-32 h-1 bg-gray-400 mx-auto mb-2"></div>
                      <p className="text-sm font-semibold">Instrutor Responsável</p>
                      <p className="text-xs text-gray-600">Eng. de Segurança do Trabalho</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6">
                  <Badge className="bg-green-500 hover:bg-green-600 text-white px-4 py-2">
                    Certificado Válido - MTE
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-green-500 hover:bg-green-600">
              <Download className="h-5 w-5 mr-2" />
              Baixar Certificado
            </Button>
            <Button size="lg" variant="outline">
              <Share2 className="h-5 w-5 mr-2" />
              Compartilhar
            </Button>
            <Button size="lg" variant="outline" onClick={() => (window.location.href = "/")}>
              Voltar ao Início
            </Button>
          </div>

          {/* Next Steps */}
          <Card className="mt-8">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Próximos Passos</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">Continue Aprendendo</h4>
                  <p className="text-sm text-blue-700">Explore outros cursos de segurança do trabalho</p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <h4 className="font-medium text-green-900 mb-2">Aplique na Prática</h4>
                  <p className="text-sm text-green-700">Use os conhecimentos adquiridos no seu trabalho</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
