"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { ChevronLeft, ChevronRight, Download, Play, FileText, CheckCircle } from "lucide-react"

interface CourseContentProps {
  module: {
    id: number
    title: string
    duration: string
    completed: boolean
    content: any
  }
  onComplete: () => void
  onNext: () => void
  onPrevious: () => void
  canGoNext: boolean
  canGoPrevious: boolean
}

export function CourseContent({
  module,
  onComplete,
  onNext,
  onPrevious,
  canGoNext,
  canGoPrevious,
}: CourseContentProps) {
  const [quizAnswers, setQuizAnswers] = useState<number[]>([])
  const [checklistItems, setChecklistItems] = useState<boolean[]>([])
  const [showResults, setShowResults] = useState(false)

  const handleQuizSubmit = () => {
    setShowResults(true)
    const correctAnswers = module.content.questions.filter(
      (q: any, index: number) => q.correct === quizAnswers[index],
    ).length

    if (correctAnswers >= module.content.questions.length * 0.7) {
      onComplete()
    }
  }

  const handleChecklistComplete = () => {
    if (checklistItems.every((item) => item)) {
      onComplete()
    }
  }

  const renderContent = () => {
    switch (module.content.type) {
      case "video":
        return (
          <div className="space-y-6">
            <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center">
              <Button size="lg" className="bg-green-500 hover:bg-green-600">
                <Play className="h-6 w-6 mr-2" />
                Reproduzir Vídeo
              </Button>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">{module.content.title}</h3>
              <p className="text-gray-600">{module.content.description}</p>
            </div>
          </div>
        )

      case "text":
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">{module.content.title}</h3>
              <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: module.content.text }} />
            </div>
          </div>
        )

      case "interactive":
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">{module.content.title}</h3>
              <p className="text-gray-600 mb-6">{module.content.description}</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {module.content.interactive.items.map((item: any, index: number) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      className="w-full h-32 object-cover rounded-lg mb-3"
                    />
                    <h4 className="font-medium mb-2">{item.name}</h4>
                    <p className="text-sm text-gray-600">{item.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )

      case "checklist":
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">{module.content.title}</h3>
              <p className="text-gray-600 mb-6">{module.content.description}</p>
            </div>

            <div className="space-y-3">
              {module.content.checklist.map((item: string, index: number) => (
                <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <Checkbox
                    id={`checklist-${index}`}
                    checked={checklistItems[index] || false}
                    onCheckedChange={(checked) => {
                      const newItems = [...checklistItems]
                      newItems[index] = checked as boolean
                      setChecklistItems(newItems)
                    }}
                  />
                  <label
                    htmlFor={`checklist-${index}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {item}
                  </label>
                </div>
              ))}
            </div>

            <Button
              onClick={handleChecklistComplete}
              disabled={!checklistItems.every((item) => item)}
              className="bg-green-500 hover:bg-green-600"
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Marcar como Concluído
            </Button>
          </div>
        )

      case "quiz":
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">{module.content.title}</h3>
              <p className="text-gray-600 mb-6">{module.content.description}</p>
            </div>

            {!showResults ? (
              <div className="space-y-6">
                {module.content.questions.map((question: any, qIndex: number) => (
                  <Card key={qIndex}>
                    <CardHeader>
                      <CardTitle className="text-base">
                        Questão {qIndex + 1}: {question.question}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {question.options.map((option: string, oIndex: number) => (
                          <button
                            key={oIndex}
                            onClick={() => {
                              const newAnswers = [...quizAnswers]
                              newAnswers[qIndex] = oIndex
                              setQuizAnswers(newAnswers)
                            }}
                            className={`w-full text-left p-3 rounded-lg border transition-colors ${
                              quizAnswers[qIndex] === oIndex
                                ? "border-green-500 bg-green-50"
                                : "border-gray-200 hover:bg-gray-50"
                            }`}
                          >
                            {option}
                          </button>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}

                <Button
                  onClick={handleQuizSubmit}
                  disabled={quizAnswers.length !== module.content.questions.length}
                  className="bg-green-500 hover:bg-green-600"
                >
                  Finalizar Avaliação
                </Button>
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="mb-4">
                  <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-green-700">Parabéns!</h3>
                  <p className="text-gray-600">Você concluiu a avaliação com sucesso!</p>
                </div>
              </div>
            )}
          </div>
        )

      default:
        return <div>Conteúdo não encontrado</div>
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              {module.title}
              {module.completed && <CheckCircle className="h-5 w-5 text-green-500" />}
            </CardTitle>
            <div className="flex items-center gap-4 mt-2">
              <Badge variant="outline">{module.duration}</Badge>
              <span className="text-sm text-gray-500">Módulo {module.id}</span>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {renderContent()}

        {/* Materials */}
        {module.content.materials && (
          <div className="mt-8 p-4 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-3 flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Materiais de Apoio
            </h4>
            <div className="space-y-2">
              {module.content.materials.map((material: string, index: number) => (
                <div key={index}>
                  {material.includes("Apresentação NR-35 Completa (PPTX)") ? (
                    <a
                      href="/materials/Curso_NR35_8horas.pptx"
                      download="Curso_NR35_8horas.pptx"
                      className="flex items-center gap-2 text-sm text-blue-700 hover:text-blue-900 hover:underline"
                    >
                      <Download className="h-4 w-4" />
                      {material}
                    </a>
                  ) : (
                    <button className="flex items-center gap-2 text-sm text-blue-700 hover:text-blue-900">
                      <Download className="h-4 w-4" />
                      {material}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Navigation */}
        <div className="flex justify-between items-center mt-8 pt-6 border-t">
          <Button variant="outline" onClick={onPrevious} disabled={!canGoPrevious}>
            <ChevronLeft className="h-4 w-4 mr-2" />
            Anterior
          </Button>

          {!module.completed && module.content.type !== "quiz" && module.content.type !== "checklist" && (
            <Button onClick={onComplete} className="bg-green-500 hover:bg-green-600">
              <CheckCircle className="h-4 w-4 mr-2" />
              Marcar como Concluído
            </Button>
          )}

          <Button onClick={onNext} disabled={!canGoNext || !module.completed} className="bg-blue-600 hover:bg-blue-700">
            Próximo
            <ChevronRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
