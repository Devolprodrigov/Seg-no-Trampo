import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, Clock, Users } from "lucide-react"
import Link from "next/link"

interface CourseHeaderProps {
  courseName: string
  progress: {
    completedModules: number
    totalModules: number
    currentModule: number
    timeSpent: number
  }
}

export function CourseHeader({ courseName, progress }: CourseHeaderProps) {
  const progressPercentage = (progress.completedModules / progress.totalModules) * 100

  return (
    <header className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold text-gray-900">{courseName}</h1>
              <p className="text-sm text-gray-600">
                Módulo {progress.currentModule} de {progress.totalModules}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Clock className="h-4 w-4" />
              <span>
                {Math.floor(progress.timeSpent / 60)}h {progress.timeSpent % 60}min
              </span>
            </div>

            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Users className="h-4 w-4" />
              <span>2.500+ alunos</span>
            </div>

            <div className="w-32">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Progresso</span>
                <span>{Math.round(progressPercentage)}%</span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
