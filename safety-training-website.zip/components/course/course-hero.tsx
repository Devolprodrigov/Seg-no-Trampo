"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Clock, Users, Star, Award, Shield, Play, Download } from "lucide-react"

interface CourseHeroProps {
  course: {
    title: string
    description: string
    image: string
    duration: string
    students: string
    rating: number
    price: string
    originalPrice: string
    badge: string
    category: string
    level: string
    modules: number
  }
}

export function CourseHero({ course }: CourseHeroProps) {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "altura":
        return "🏗️"
      case "espacos-confinados":
        return "🏭"
      case "eletricidade":
        return "⚡"
      case "cipa":
        return "👥"
      case "primeiros-socorros":
        return "🚑"
      case "soldagem":
        return "🔥"
      default:
        return "🛡️"
    }
  }

  return (
    <section className="relative py-20 bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 text-white overflow-hidden">
      <div className="absolute inset-0 bg-black/20"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="text-3xl">{getCategoryIcon(course.category)}</div>
                <Badge className="bg-green-500 hover:bg-green-600 text-white px-4 py-2">{course.badge}</Badge>
              </div>

              <h1 className="text-4xl lg:text-5xl font-bold leading-tight">{course.title}</h1>

              <p className="text-xl text-blue-100 leading-relaxed">{course.description}</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-3 bg-white/10 backdrop-blur-sm rounded-lg">
                <Clock className="h-6 w-6 text-green-400 mx-auto mb-2" />
                <div className="text-sm font-medium">{course.duration}</div>
                <div className="text-xs text-blue-200">Duração</div>
              </div>

              <div className="text-center p-3 bg-white/10 backdrop-blur-sm rounded-lg">
                <Users className="h-6 w-6 text-green-400 mx-auto mb-2" />
                <div className="text-sm font-medium">{course.students}</div>
                <div className="text-xs text-blue-200">Alunos</div>
              </div>

              <div className="text-center p-3 bg-white/10 backdrop-blur-sm rounded-lg">
                <Star className="h-6 w-6 text-green-400 mx-auto mb-2" />
                <div className="text-sm font-medium">{course.rating}</div>
                <div className="text-xs text-blue-200">Avaliação</div>
              </div>

              <div className="text-center p-3 bg-white/10 backdrop-blur-sm rounded-lg">
                <Shield className="h-6 w-6 text-green-400 mx-auto mb-2" />
                <div className="text-sm font-medium">{course.modules}</div>
                <div className="text-xs text-blue-200">Módulos</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-green-500 hover:bg-green-600 text-lg px-8 py-4">
                <Play className="h-5 w-5 mr-2" />
                Começar Agora
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-blue-900 text-lg px-8 py-4 bg-transparent"
              >
                <Download className="h-5 w-5 mr-2" />
                Baixar Materiais
              </Button>
            </div>
          </div>

          <div className="relative">
            <Card className="overflow-hidden shadow-2xl">
              <div className="relative">
                <img src={course.image || "/placeholder.svg"} alt={course.title} className="w-full h-80 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center justify-between text-white">
                    <div>
                      <div className="text-2xl font-bold text-green-400">{course.price}</div>
                      <div className="text-sm line-through opacity-75">{course.originalPrice}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Award className="h-5 w-5 text-green-400" />
                      <span className="text-sm font-medium">Certificado MTE</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
