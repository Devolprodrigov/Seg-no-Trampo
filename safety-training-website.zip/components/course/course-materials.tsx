"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, FileText, Presentation, FileCheck, BookOpen } from "lucide-react"

export function CourseMaterials() {
  const materials = [
    {
      name: "Apresentação NR-35 Completa",
      type: "PPTX",
      size: "2.5 MB",
      description: "Apresentação completa do curso com 8 horas de conteúdo",
      icon: Presentation,
      downloadUrl: "/materials/Curso_NR35_8horas.pptx",
      featured: true,
    },
    {
      name: "Manual da NR-35 Atualizado",
      type: "PDF",
      size: "1.2 MB",
      description: "Versão oficial da Norma Regulamentadora 35",
      icon: BookOpen,
      downloadUrl: "#",
      featured: false,
    },
    {
      name: "Checklist de Segurança",
      type: "PDF",
      size: "0.8 MB",
      description: "Lista de verificação para trabalhos em altura",
      icon: FileCheck,
      downloadUrl: "#",
      featured: false,
    },
    {
      name: "Formulário de Análise de Risco",
      type: "DOC",
      size: "0.5 MB",
      description: "Modelo de formulário para AR",
      icon: FileText,
      downloadUrl: "#",
      featured: false,
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5 text-green-500" />
          Materiais do Curso
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {materials.map((material, index) => (
            <div
              key={index}
              className={`p-4 rounded-lg border transition-colors ${
                material.featured ? "bg-green-50 border-green-200" : "bg-gray-50 border-gray-200"
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg ${material.featured ? "bg-green-100" : "bg-white"}`}>
                    <material.icon className={`h-5 w-5 ${material.featured ? "text-green-600" : "text-gray-600"}`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-gray-900">{material.name}</h4>
                      {material.featured && <Badge className="bg-green-500 hover:bg-green-600 text-xs">Destaque</Badge>}
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{material.description}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span>{material.type}</span>
                      <span>{material.size}</span>
                    </div>
                  </div>
                </div>
                <div className="flex-shrink-0">
                  {material.downloadUrl !== "#" ? (
                    <a href={material.downloadUrl} download>
                      <Button
                        size="sm"
                        className={
                          material.featured ? "bg-green-500 hover:bg-green-600" : "bg-blue-500 hover:bg-blue-600"
                        }
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Baixar
                      </Button>
                    </a>
                  ) : (
                    <Button size="sm" variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      Baixar
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h5 className="font-medium text-blue-900 mb-2">💡 Dica de Estudo</h5>
          <p className="text-sm text-blue-700">
            Baixe a apresentação completa para acompanhar o curso offline e revisar o conteúdo sempre que necessário.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
