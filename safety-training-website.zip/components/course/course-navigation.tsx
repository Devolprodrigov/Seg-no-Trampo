"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Circle, Play } from "lucide-react"

interface Module {
  id: number
  title: string
  duration: string
  completed: boolean
}

interface CourseNavigationProps {
  modules: Module[]
  currentModule: number
  onModuleSelect: (moduleId: number) => void
}

export function CourseNavigation({ modules, currentModule, onModuleSelect }: CourseNavigationProps) {
  return (
    <Card>
      <CardContent className="p-4">
        <h3 className="font-semibold text-gray-900 mb-4">Módulos do Curso</h3>
        <div className="space-y-2">
          {modules.map((module) => (
            <button
              key={module.id}
              onClick={() => onModuleSelect(module.id)}
              className={`w-full text-left p-3 rounded-lg transition-colors ${
                currentModule === module.id ? "bg-green-50 border border-green-200" : "hover:bg-gray-50"
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="flex-shrink-0">
                  {module.completed ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : currentModule === module.id ? (
                    <Play className="h-5 w-5 text-green-500" />
                  ) : (
                    <Circle className="h-5 w-5 text-gray-400" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p
                    className={`text-sm font-medium ${
                      currentModule === module.id ? "text-green-700" : "text-gray-900"
                    }`}
                  >
                    {module.title}
                  </p>
                  <p className="text-xs text-gray-500">{module.duration}</p>
                </div>
                {module.completed && (
                  <Badge variant="secondary" className="bg-green-100 text-green-700">
                    Concluído
                  </Badge>
                )}
              </div>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
