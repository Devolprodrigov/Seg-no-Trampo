import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Trophy, Clock, Target } from "lucide-react"

interface CourseProgressProps {
  progress: {
    completedModules: number
    totalModules: number
    currentModule: number
    timeSpent: number
  }
}

export function CourseProgress({ progress }: CourseProgressProps) {
  const progressPercentage = (progress.completedModules / progress.totalModules) * 100

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Seu Progresso</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Progresso Geral</span>
            <span>{Math.round(progressPercentage)}%</span>
          </div>
          <Progress value={progressPercentage} className="h-2" />
        </div>

        <div className="grid grid-cols-1 gap-3">
          <div className="flex items-center gap-2 text-sm">
            <Target className="h-4 w-4 text-green-500" />
            <span>
              {progress.completedModules}/{progress.totalModules} módulos
            </span>
          </div>

          <div className="flex items-center gap-2 text-sm">
            <Clock className="h-4 w-4 text-blue-500" />
            <span>
              {Math.floor(progress.timeSpent / 60)}h {progress.timeSpent % 60}min estudados
            </span>
          </div>

          {progressPercentage === 100 && (
            <div className="flex items-center gap-2 text-sm text-green-600">
              <Trophy className="h-4 w-4" />
              <span>Curso Concluído!</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
