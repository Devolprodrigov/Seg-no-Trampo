"use client"

import { useState } from "react"
import { CourseCard } from "@/components/course-card"
import { CourseCategories } from "@/components/course-categories"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

export function CoursesSection() {
  const [activeCategory, setActiveCategory] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")

  const courses = [
    {
      id: "nr35",
      title: "NR-35 - Trabalho em Altura",
      description:
        "Curso completo sobre segurança em trabalhos em altura conforme NR-35. Aprenda procedimentos, EPIs e análise de riscos.",
      image: "/images/courses/nr35-cover.png",
      duration: "8 horas",
      students: "2.500+",
      rating: 4.9,
      price: "R$ 89,90",
      originalPrice: "R$ 149,90",
      badge: "Mais Vendido",
      category: "altura",
      level: "Básico",
      modules: 5,
    },
    {
      id: "nr33",
      title: "NR-33 - Espaços Confinados",
      description:
        "Treinamento essencial para trabalhos em espaços confinados. Procedimentos de entrada, monitoramento e resgate.",
      image: "/images/courses/nr33-cover.png",
      duration: "16 horas",
      students: "1.800+",
      rating: 4.8,
      price: "R$ 129,90",
      originalPrice: "R$ 199,90",
      badge: "Certificado MTE",
      category: "espacos-confinados",
      level: "Intermediário",
      modules: 6,
    },
    {
      id: "nr10",
      title: "NR-10 - Segurança em Eletricidade",
      description:
        "Curso básico de segurança em instalações e serviços em eletricidade. Riscos elétricos e medidas de proteção.",
      image: "/images/courses/nr10-cover.png",
      duration: "40 horas",
      students: "3.200+",
      rating: 4.9,
      price: "R$ 199,90",
      originalPrice: "R$ 299,90",
      badge: "Completo",
      category: "eletricidade",
      level: "Básico",
      modules: 8,
    },
    {
      id: "cipa",
      title: "CIPA - Comissão Interna",
      description: "Formação completa para membros da CIPA conforme NR-05. Prevenção de acidentes e promoção da saúde.",
      image: "/images/courses/cipa-cover.png",
      duration: "20 horas",
      students: "1.500+",
      rating: 4.7,
      price: "R$ 149,90",
      originalPrice: "R$ 249,90",
      badge: "Atualizado",
      category: "cipa",
      level: "Básico",
      modules: 7,
    },
    {
      id: "primeiros-socorros",
      title: "Primeiros Socorros",
      description:
        "Treinamento prático em primeiros socorros no ambiente de trabalho. Técnicas de salvamento e atendimento emergencial.",
      image: "/images/courses/primeiros-socorros-cover.png",
      duration: "12 horas",
      students: "2.100+",
      rating: 4.8,
      price: "R$ 99,90",
      originalPrice: "R$ 159,90",
      badge: "Prático",
      category: "primeiros-socorros",
      level: "Básico",
      modules: 4,
    },
    {
      id: "soldagem",
      title: "Segurança em Soldagem",
      description:
        "Curso especializado em segurança para atividades de soldagem. Riscos, EPIs e procedimentos seguros.",
      image: "/images/courses/soldagem-cover.png",
      duration: "6 horas",
      students: "900+",
      rating: 4.6,
      price: "R$ 79,90",
      originalPrice: "R$ 129,90",
      badge: "Especializado",
      category: "soldagem",
      level: "Intermediário",
      modules: 3,
    },
    {
      id: "empilhadeira",
      title: "Operador de Empilhadeira",
      description:
        "Capacitação completa para operadores de empilhadeira. Segurança, manutenção e operação responsável.",
      image: "/images/courses/empilhadeira-cover.png",
      duration: "16 horas",
      students: "1.200+",
      rating: 4.7,
      price: "R$ 159,90",
      originalPrice: "R$ 249,90",
      badge: "Certificação",
      category: "equipamentos",
      level: "Básico",
      modules: 6,
    },
    {
      id: "direcao-defensiva",
      title: "Direção Defensiva",
      description:
        "Técnicas de direção defensiva para prevenção de acidentes. Comportamento seguro no trânsito corporativo.",
      image: "/images/courses/direcao-defensiva-cover.png",
      duration: "8 horas",
      students: "2.800+",
      rating: 4.8,
      price: "R$ 69,90",
      originalPrice: "R$ 119,90",
      badge: "Popular",
      category: "transporte",
      level: "Básico",
      modules: 4,
    },
    {
      id: "analise-acidentes",
      title: "Análise de Acidentes",
      description:
        "Metodologia para investigação e análise de acidentes de trabalho. Identificação de causas e medidas preventivas.",
      image: "/images/courses/analise-acidentes-cover.png",
      duration: "12 horas",
      students: "850+",
      rating: 4.9,
      price: "R$ 119,90",
      originalPrice: "R$ 189,90",
      badge: "Técnico",
      category: "investigacao",
      level: "Avançado",
      modules: 5,
    },
    {
      id: "5-porques",
      title: "Metodologia 5 Porquês",
      description:
        "Técnica de análise de causa raiz através da metodologia dos 5 Porquês. Ferramenta essencial para resolução de problemas.",
      image: "/images/courses/5-porques-cover.png",
      duration: "4 horas",
      students: "1.100+",
      rating: 4.6,
      price: "R$ 49,90",
      originalPrice: "R$ 89,90",
      badge: "Rápido",
      category: "metodologia",
      level: "Intermediário",
      modules: 3,
    },
    {
      id: "sikicaua",
      title: "SIKICAUA - Identificação de Perigos",
      description:
        "Sistema de Identificação de Perigos e Controle de Riscos. Metodologia avançada para gestão de segurança.",
      image: "/images/courses/sikicaua-cover.png",
      duration: "24 horas",
      students: "650+",
      rating: 4.8,
      price: "R$ 249,90",
      originalPrice: "R$ 399,90",
      badge: "Avançado",
      category: "gestao-riscos",
      level: "Avançado",
      modules: 8,
    },
  ]

  const filteredCourses = courses.filter((course) => {
    const matchesCategory = activeCategory === "all" || course.category === activeCategory
    const matchesSearch =
      course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.description.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <section id="cursos" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Cursos Online Disponíveis</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Certificações reconhecidas pelo MTE com metodologia prática e conteúdo atualizado. Estude no seu ritmo com
            suporte especializado.
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-md mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              type="text"
              placeholder="Buscar cursos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Categories */}
        <CourseCategories activeCategory={activeCategory} onCategoryChange={setActiveCategory} />

        {/* Courses Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredCourses.map((course, index) => (
            <CourseCard key={index} course={course} />
          ))}
        </div>

        {filteredCourses.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">Nenhum curso encontrado para os filtros selecionados.</p>
          </div>
        )}

        <div className="text-center mt-12">
          <Button size="lg" variant="outline" className="border-blue-900 text-blue-900 hover:bg-blue-50 bg-transparent">
            Ver Todos os Cursos
          </Button>
        </div>
      </div>
    </section>
  )
}
