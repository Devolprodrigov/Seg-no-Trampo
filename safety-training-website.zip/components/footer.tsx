import Link from "next/link"
import { Shield, Facebook, Instagram, Linkedin, Youtube, Mail, Phone, MapPin } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-blue-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-6">
            <Link href="/" className="flex items-center gap-2">
              <Shield className="h-8 w-8 text-green-400" />
              <div>
                <h3 className="text-xl font-bold">Segurança no Trampo</h3>
                <p className="text-sm text-blue-200">Treinamentos & Assessoria</p>
              </div>
            </Link>
            <p className="text-blue-200 leading-relaxed">
              Referência em treinamentos de segurança do trabalho há mais de 10 anos. Certificações reconhecidas pelo
              MTE.
            </p>
            <div className="flex gap-4">
              <Link href="#" className="p-2 bg-blue-800 rounded-full hover:bg-green-500 transition-colors">
                <Facebook className="h-5 w-5" />
              </Link>
              <Link href="#" className="p-2 bg-blue-800 rounded-full hover:bg-green-500 transition-colors">
                <Instagram className="h-5 w-5" />
              </Link>
              <Link href="#" className="p-2 bg-blue-800 rounded-full hover:bg-green-500 transition-colors">
                <Linkedin className="h-5 w-5" />
              </Link>
              <Link href="#" className="p-2 bg-blue-800 rounded-full hover:bg-green-500 transition-colors">
                <Youtube className="h-5 w-5" />
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h4 className="text-lg font-semibold">Links Rápidos</h4>
            <ul className="space-y-3">
              <li>
                <Link href="#inicio" className="text-blue-200 hover:text-green-400 transition-colors">
                  Início
                </Link>
              </li>
              <li>
                <Link href="#cursos" className="text-blue-200 hover:text-green-400 transition-colors">
                  Cursos
                </Link>
              </li>
              <li>
                <Link href="#servicos" className="text-blue-200 hover:text-green-400 transition-colors">
                  Serviços
                </Link>
              </li>
              <li>
                <Link href="#sobre" className="text-blue-200 hover:text-green-400 transition-colors">
                  Sobre
                </Link>
              </li>
              <li>
                <Link href="#contato" className="text-blue-200 hover:text-green-400 transition-colors">
                  Contato
                </Link>
              </li>
            </ul>
          </div>

          {/* Courses */}
          <div className="space-y-6">
            <h4 className="text-lg font-semibold">Cursos Populares</h4>
            <ul className="space-y-3">
              <li>
                <Link href="#" className="text-blue-200 hover:text-green-400 transition-colors">
                  NR-35 - Trabalho em Altura
                </Link>
              </li>
              <li>
                <Link href="#" className="text-blue-200 hover:text-green-400 transition-colors">
                  NR-33 - Espaços Confinados
                </Link>
              </li>
              <li>
                <Link href="#" className="text-blue-200 hover:text-green-400 transition-colors">
                  NR-10 - Segurança Elétrica
                </Link>
              </li>
              <li>
                <Link href="#" className="text-blue-200 hover:text-green-400 transition-colors">
                  CIPA - Comissão Interna
                </Link>
              </li>
              <li>
                <Link href="#" className="text-blue-200 hover:text-green-400 transition-colors">
                  Primeiros Socorros
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            <h4 className="text-lg font-semibold">Contato</h4>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-green-400 flex-shrink-0" />
                <div className="text-blue-200">
                  <div>(11) 99999-9999</div>
                  <div>(11) 3333-4444</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-green-400 flex-shrink-0" />
                <div className="text-blue-200">contato@segurancanotrampo.com.br</div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-green-400 flex-shrink-0 mt-1" />
                <div className="text-blue-200">
                  Rua da Segurança, 123
                  <br />
                  Centro - São Paulo/SP
                  <br />
                  CEP: 01234-567
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-blue-800">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-blue-200 text-sm">© 2024 Segurança no Trampo. Todos os direitos reservados.</div>
            <div className="flex gap-6 text-sm">
              <Link href="#" className="text-blue-200 hover:text-green-400 transition-colors">
                Política de Privacidade
              </Link>
              <Link href="#" className="text-blue-200 hover:text-green-400 transition-colors">
                Termos de Uso
              </Link>
              <Link href="#" className="text-blue-200 hover:text-green-400 transition-colors">
                Certificados
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
