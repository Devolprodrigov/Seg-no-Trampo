"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, Shield, Phone, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="bg-white shadow-sm border-b">
      {/* Top bar */}
      <div className="bg-blue-900 text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4" />
              <span>(11) 99999-9999</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4" />
              <span>contato@segurancanotrampo.com.br</span>
            </div>
          </div>
          <div className="hidden md:block">
            <span>Certificados reconhecidos pelo MTE</span>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Shield className="h-8 w-8 text-green-500" />
            <div>
              <h1 className="text-xl font-bold text-blue-900">Segurança no Trampo</h1>
              <p className="text-xs text-gray-600">Treinamentos & Assessoria</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            <Link href="#inicio" className="text-gray-700 hover:text-green-500 font-medium">
              Início
            </Link>
            <Link href="#cursos" className="text-gray-700 hover:text-green-500 font-medium">
              Cursos
            </Link>
            <Link href="#servicos" className="text-gray-700 hover:text-green-500 font-medium">
              Serviços
            </Link>
            <Link href="#sobre" className="text-gray-700 hover:text-green-500 font-medium">
              Sobre
            </Link>
            <Link href="#contato" className="text-gray-700 hover:text-green-500 font-medium">
              Contato
            </Link>
          </nav>

          <div className="hidden lg:flex items-center gap-4">
            <Button variant="outline" className="border-green-500 text-green-500 hover:bg-green-50 bg-transparent">
              Login
            </Button>
            <Button className="bg-green-500 hover:bg-green-600">Matricule-se</Button>
          </div>

          {/* Mobile menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80">
              <div className="flex flex-col gap-6 mt-8">
                <Link href="#inicio" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                  Início
                </Link>
                <Link href="#cursos" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                  Cursos
                </Link>
                <Link href="#servicos" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                  Serviços
                </Link>
                <Link href="#sobre" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                  Sobre
                </Link>
                <Link href="#contato" className="text-lg font-medium" onClick={() => setIsOpen(false)}>
                  Contato
                </Link>
                <div className="flex flex-col gap-3 mt-6">
                  <Button variant="outline" className="border-green-500 text-green-500 bg-transparent">
                    Login
                  </Button>
                  <Button className="bg-green-500 hover:bg-green-600">Matricule-se</Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
