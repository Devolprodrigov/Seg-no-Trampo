import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Shield, FileText, Users, Briefcase, CheckCircle } from "lucide-react"

export function ServicesSection() {
  const services = [
    {
      icon: Shield,
      title: "Assessoria em SST",
      description: "Consultoria especializada em Segurança e Saúde no Trabalho para sua empresa.",
      features: ["PPRA", "PCMSO", "LTCAT", "Laudos Técnicos"],
    },
    {
      icon: FileText,
      title: "Elaboração de Documentos",
      description: "Documentação técnica completa para atender às normas regulamentadoras.",
      features: ["PGR", "PCMAT", "PPP", "Relatórios Técnicos"],
    },
    {
      icon: Users,
      title: "Treinamentos In Company",
      description: "Treinamentos personalizados na sua empresa com instrutores qualificados.",
      features: ["NR-35", "NR-33", "NR-10", "CIPA"],
    },
    {
      icon: Briefcase,
      title: "Gestão de SST",
      description: "Implementação de sistemas de gestão de segurança e saúde ocupacional.",
      features: ["ISO 45001", "Auditorias", "Indicadores", "Melhorias"],
    },
  ]

  return (
    <section id="servicos" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Nossos Serviços</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Oferecemos soluções completas em segurança do trabalho para proteger sua equipe e garantir o cumprimento das
            normas regulamentadoras.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow border-0 shadow-md">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 p-3 bg-green-100 rounded-full w-fit">
                  <service.icon className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-xl text-gray-900">{service.title}</CardTitle>
                <CardDescription className="text-gray-600">{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                      <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button className="w-full bg-blue-900 hover:bg-blue-800">Solicitar Orçamento</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
