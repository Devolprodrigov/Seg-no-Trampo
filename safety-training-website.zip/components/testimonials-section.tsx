import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star } from "lucide-react"

export function TestimonialsSection() {
  const testimonials = [
    {
      name: "Carlos Silva",
      role: "Técnico em Segurança",
      company: "Construtora ABC",
      content:
        "Excelente curso de NR-35! Conteúdo muito bem estruturado e instrutores qualificados. Recomendo para todos os profissionais da área.",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
    },
    {
      name: "Maria Santos",
      role: "Engenheira de Segurança",
      company: "Indústria XYZ",
      content:
        "A Segurança no Trampo oferece os melhores treinamentos do mercado. Já fiz vários cursos e sempre saio muito satisfeita com a qualidade.",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
    },
    {
      name: "João Oliveira",
      role: "Supervisor de Obras",
      company: "Obras & Cia",
      content:
        "Plataforma muito intuitiva e suporte excelente. Os certificados são reconhecidos e aceitos em todas as empresas que trabalhei.",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
    },
    {
      name: "Ana Costa",
      role: "Coordenadora de RH",
      company: "Empresa DEF",
      content:
        "Contratamos a Segurança no Trampo para treinar nossa equipe. Profissionalismo exemplar e resultados excelentes. Parceria de longa data!",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
    },
    {
      name: "Roberto Lima",
      role: "Eletricista Industrial",
      company: "Elétrica Pro",
      content:
        "O curso de NR-10 foi fundamental para minha carreira. Aprendi muito e me sinto mais seguro executando meu trabalho.",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
    },
    {
      name: "Fernanda Rocha",
      role: "Técnica em Enfermagem",
      company: "Hospital São José",
      content:
        "Fiz o curso de Primeiros Socorros e foi excelente! Muito prático e aplicável no dia a dia. Instrutores muito preparados.",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
    },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">O que nossos alunos dizem</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Mais de 15.000 profissionais já confiaram em nossos treinamentos. Veja os depoimentos de quem já fez parte
            da nossa comunidade.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                <p className="text-gray-700 mb-6 leading-relaxed">"{testimonial.content}"</p>

                <div className="flex items-center gap-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                    <AvatarFallback>
                      {testimonial.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-600">{testimonial.role}</div>
                    <div className="text-sm text-green-600">{testimonial.company}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
